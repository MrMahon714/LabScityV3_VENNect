"use client";

import Image from "next/image";
import type { CSSProperties } from "react";

/**
 * Login/signup logo. Renders both versions; CSS shows the dark logo in light
 * mode and the light-gray logo in dark mode.
 */
export function LSAuthLogo({
  width,
  height,
  style,
  priority,
}: {
  width: number;
  height: number;
  style?: CSSProperties;
  priority?: boolean;
}) {
  return (
    <>
      <Image
        className="ls-logo-for-light"
        src="/logo.png"
        alt="LabScity Logo"
        width={width}
        height={height}
        priority={priority}
        style={style}
      />
      <Image
        className="ls-logo-for-dark"
        src="/logo-lightgray.png"
        alt="LabScity Logo"
        width={width}
        height={height}
        priority={priority}
        style={style}
      />
    </>
  );
}
