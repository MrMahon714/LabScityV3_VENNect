"use client";

import { ActionIcon, Anchor, Avatar, Box, Button, Group, Menu, Spoiler, Text, UnstyledButton } from "@mantine/core";
import Link from "next/link";
import { IconDots, IconHeart, IconHeartFilled } from "@tabler/icons-react";
import type { FeedCommentItem } from "@/lib/types/feed";
import { useRef } from "react";

/**
 * Props for LSPostCommentCard.
 *
 * @param comment - FeedCommentItem (userName, userId, content, timeAgo, avatarUrl, isLiked, id).
 * @param onLikeClick - Called with comment id when like is clicked.
 * @param onReportClick - Called with comment id when Report is chosen from menu.
 * @param showMenu - Whether to show the options menu (Report).
 * @param showActions - Whether to show the like button.
 * @param menuId - Optional id for the menu (accessibility).
 */
interface LSPostCommentCardProps {
  comment: FeedCommentItem;
  onLikeClick?: () => void;
  onReportClick?: () => void;
  onReplyClick?: () => void;
  showMenu?: boolean;
  showActions?: boolean;
  menuId?: string;
}

/**
 * Compact comment row: avatar, author name (link to profile when userId set), content,
 * time, optional like button, and optional menu (Report). Used below posts in feed and post detail.
 */
export function LSPostCommentCard({
  comment,
  onLikeClick,
  onReportClick,
  onReplyClick,
  showMenu = true,
  showActions = true,
  menuId,
}: LSPostCommentCardProps) {
  const noPropagate = (fn?: () => void) => {
    return (e: React.MouseEvent) => {
      e.stopPropagation();
      fn?.();
    };
  }
 
  const spoilerControlRef = useRef<HTMLButtonElement>(null);

  const initials = comment.userName
    .split(" ")
    .filter(Boolean)
    .map((part) => part[0])
    .slice(0, 2)
    .join("");

  const nameNode = comment.userId ? (
    <Anchor onClick={noPropagate()} component={Link} href={`/profile/${comment.userId}`} underline="hover" c="var(--ls-text-strong)">
      <Text component="span" fw="bold" c="var(--ls-text-strong)" size="sm" style={{ cursor: "pointer" }}>
        {comment.userName}
      </Text>
    </Anchor>
  ) : (
    <Text component="span" fw="bold" c="var(--ls-text-strong)" size="sm">{comment.userName}</Text>
  );

  return (
    <Group align="flex-start" gap="sm" w="100%" wrap="nowrap">
      <Avatar
        size={36}
        radius="xl"
        color="navy.7"
        bg="navy.7"
        src={comment.avatarUrl || undefined}
        style={{ flexShrink: 0 }}
      >
        {initials}
      </Avatar>

      <Box style={{ flex: 1, minWidth: 0 }}>
        <Box
          onClick={(e) => {
            if (spoilerControlRef.current?.contains(e.target as Node)) {
              e.stopPropagation();
            }
          }}
        >
          <Spoiler 
            controlRef={spoilerControlRef}
            fz="sm" 
            maxHeight={92} // Enough for about 4 lines worth of comment
            showLabel='Show more'
            hideLabel='Hide'
            style={{
              overflowWrap: "anywhere",
              wordBreak: "break-word",
              whiteSpace: "pre-wrap",
            }}
            styles={{
              control: {
                color: 'var(--mantine-color-indigo-7)',
                fontSize: 'var(--mantine-font-size-sm)',
                fontWeight: 600
              }
            }}
          >
            {nameNode}{" "}{comment.content}
          </Spoiler>
        </Box>

        <Group justify="flex-start" gap="xs" mt={4}>
          <Text size="xs" c="navy.5" style={{ whiteSpace: "nowrap" }}>{comment.timeAgo}</Text>
          {onReplyClick ? (
            <Button
              variant="subtle"
              color="gray"
              size="compact-xs"
              px={0}
              onClick={noPropagate(onReplyClick)}
            >
              Reply
            </Button>
          ) : null}
          {showMenu ? (
            <Menu
              withinPortal
              position="bottom-end"
              styles={{
                dropdown: { padding: "6px" },
                item: { borderRadius: "var(--mantine-radius-md)", fontWeight: 600, color: "var(--ls-text-strong)" },
              }}
              id={menuId}
            >
              <Menu.Target>
                <ActionIcon onClick={noPropagate()} variant="subtle" color="navy.6" aria-label="Comment options">
                  <IconDots size={16} />
                </ActionIcon>
              </Menu.Target>
              <Menu.Dropdown>
                <Menu.Item onClick={noPropagate(onReportClick)}>Report</Menu.Item>
              </Menu.Dropdown>
            </Menu>
          ) : null}
        </Group>
      </Box>

      {showActions ? (
        <UnstyledButton
          style={{ display: "inline-flex", alignItems: "center", justifyContent: "center", padding: "4px", borderRadius: 999, flexShrink: 0 }}
          onClick={noPropagate(onLikeClick)}
        >
          {comment.isLiked ? (
            <IconHeartFilled size={18} style={{ color: "#e03131" }} />
          ) : (
            <IconHeart size={18} style={{ color: "var(--mantine-color-navy-6)" }} />
          )}
        </UnstyledButton>
      ) : null}
    </Group>
  );
}
