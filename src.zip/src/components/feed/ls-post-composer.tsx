"use client";

import { Button, Card, FileInput, Group, Select, Stack, Textarea } from "@mantine/core";
import { Controller, useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { SCIENCE_CATEGORIES } from "@/lib/constants/options";
import {
  createPostSchema,
  type CreatePostValues,
} from "@/lib/validations/post";

const postComposerSchema = createPostSchema.extend({
  mediaFile: z.any().optional().nullable(),
  imageWidth: z.number().optional().nullable(),
  imageHeight: z.number().optional().nullable()
});

/**
 * Props for LSPostComposer.
 *
 * @param onSubmit - Called with form values (scientificField, content, category, mediaFile) on submit.
 * @param isPending - When true, submit button shows loading and form can be disabled.
 */
export interface LSPostComposerProps {
  onSubmit: (values: CreatePostValues & { mediaFile?: File | null }) => void | Promise<void>;
  isPending: boolean;
}

/**
 * Post creation form: scientific field, post content textarea, optional image upload.
 * Uses SCIENCE_CATEGORIES for field options. Used on home feed; parent wires onSubmit to createPost mutation.
 */
export function LSPostComposer({ onSubmit: onSubmitProp, isPending }: LSPostComposerProps) {
  const {
    control,
    setValue,
    handleSubmit,
    formState: { errors, isSubmitting, isValid },
    register,
  } = useForm<CreatePostValues & { mediaFile?: File | null }>({
    resolver: zodResolver(postComposerSchema),
    mode: "onChange",
    defaultValues: {
      scientificField: "",
      content: "",
      category: "general",
      mediaFile: undefined,
      mediaPath: undefined,
    },
  });

  const onSubmit = handleSubmit((values) => {
    onSubmitProp(values);
  });

  return (
    <Card radius="md" shadow="sm" bg="gray.0" p="lg">
      <form onSubmit={onSubmit}>
        <Stack gap="sm">
          <Controller
            control={control}
            name="scientificField"
            render={({ field }) => (
              <Select
                label="Scientific Field"
                placeholder="Select a scientific field"
                data={SCIENCE_CATEGORIES}
                searchable
                value={field.value}
                onChange={field.onChange}
                error={errors.scientificField?.message}
                styles={{ label: { color: "var(--ls-text-strong)" } }}
              />
            )}
          />
          <Textarea
            label="Post"
            placeholder="Share an update with the community..."
            minRows={3}
            error={errors.content?.message}
            styles={{ label: { color: "var(--ls-text-strong)" } }}
            {...register("content")}
          />
          <Controller
            control={control}
            name="mediaFile"
            render={({ field }) => (
              <FileInput
                label="Picture (optional)"
                placeholder="Upload an image"
                accept="image/*"
                value={field.value ? (field.value as File) : null}
                onChange={field.onChange}
                error={errors.mediaFile?.message as string | undefined}
                styles={{ label: { color: "var(--ls-text-strong)" } }}
              />
            )}
          />
          <Group justify="flex-end">
            <Button
              type="submit"
              disabled={!isValid || isSubmitting || isPending}
              loading={isPending}
            >
              Post
            </Button>
          </Group>
        </Stack>
      </form>
    </Card>
  );
}
