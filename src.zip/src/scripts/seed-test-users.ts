import dotenv from "dotenv";
dotenv.config({ path: ".env.local" });

import { createClient } from "@supabase/supabase-js";

/**
 * Creates confirmed test accounts for local development.
 * Run from the project root: npx tsx src/scripts/seed-test-users.ts
 * Needs the service role key in .env.local; never commit that file.
 */
const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
const serviceKey =
  process.env.NEXT_SECRET_SUPABASE_KEY ??
  process.env.SUPABASE_SERVICE_ROLE_KEY ??
  process.env.SUPABASE_SECRET_KEY ??
  process.env.SERVICE_ROLE_KEY;

if (!url || !serviceKey) {
  console.error(
    [
      "Missing Supabase settings in .env.local:",
      url ? null : "  - NEXT_PUBLIC_SUPABASE_URL",
      serviceKey
        ? null
        : "  - the service role key (add it as NEXT_SECRET_SUPABASE_KEY=...)",
      "",
      "Run `npx supabase status` and copy the service_role (or secret) key.",
    ]
      .filter((line) => line !== null)
      .join("\n"),
  );
  process.exit(1);
}

const supabase = createClient(url, serviceKey, {
  auth: { autoRefreshToken: false, persistSession: false },
});

const PASSWORD = "Password123!";

const PEOPLE = [
  { first: "Alice", last: "Nguyen", occupation: "Postdoctoral Researcher", workplace: "Northwind University" },
  { first: "Ben", last: "Okafor", occupation: "PhD Student", workplace: "Harbor Institute" },
  { first: "Carla", last: "Mendez", occupation: "Lab Manager", workplace: "Northwind University" },
  { first: "Dmitri", last: "Volkov", occupation: "Professor", workplace: "Lakeside College" },
  { first: "Emi", last: "Tanaka", occupation: "Research Scientist", workplace: "Harbor Institute" },
  { first: "Farid", last: "Haddad", occupation: "Data Scientist", workplace: "Meridian Labs" },
  { first: "Grace", last: "Liu", occupation: "Graduate Student", workplace: "Lakeside College" },
  { first: "Hugo", last: "Berg", occupation: "Bioinformatician", workplace: "Meridian Labs" },
];

async function main() {
  for (const person of PEOPLE) {
    const email = `${person.first}.${person.last}@test.labscity.edu`.toLowerCase();

    const { error } = await supabase.auth.admin.createUser({
      email,
      password: PASSWORD,
      email_confirm: true,
      user_metadata: {
        first_name: person.first,
        last_name: person.last,
        occupation: person.occupation,
        workplace: person.workplace,
      },
    });

    if (error) {
      console.log(`skipped ${email}: ${error.message}`);
    } else {
      console.log(`created ${email}`);
    }
  }

  console.log(`\nAll test accounts use the password: ${PASSWORD}`);
}

main();
